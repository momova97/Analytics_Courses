#install packages
install.packages("plyr")
install.packages("readr")
install.packages("caret")
install.packages("ggplot2")
install.packages("repr")
install.packages("janitor")
install.packages("ISLR")
install.packages("dplyr")
install.packages("tidyrplyr")
install.packages("tidyverse")
install.packages("caTools")
install.packages("corrplot")
install.packages("glmnet")
install.packages("Metrics")
install.packages("forecast")
install.packages("reshape")
install.packages("lmtest")

#load libraries
library(dplyr)
library(tidyverse)
library(plyr)
library(readr)
library(dplyr)
library(caret)
library(ggplot2)
library(repr)
library(janitor)
library(caTools)
library(corrplot)
library(glmnet)
library(Metrics)
library(forecast)
library(reshape)
library(lmtest)


danfoss <- read.csv("Danfoss_FinalData.csv")
danfoss <- as.data.frame(read.csv("Danfoss_FinalData.csv",header = TRUE))
summary(danfoss)
glimpse(danfoss)
# Removing the missing value rows and columns
danfoss <- danfoss[-c(172, 173), ]
names(danfoss) <- make_clean_names(names(danfoss))

# #df <- danfoss[ , c("target_variable","emea_business_confidence_indicator_bci","emea_cli_normalized",
#                     "emea_consumer_confidence_indicator_cci","emea_crude_oil_prices",
#                     "emea_gdp_normalized","emea_germany_ifo_business_climate","emea_ifo_business_expectations","emea_ifo_business_situation",                                   
#                     "emea_pmi","emea_production_in_total_manufacturing_index","emea_production_of_total_construction_index","emea_production_of_total_industry_index",
#                     "emea_vdma_agriculture","emea_vdma_construction","emea_vdma_machine_building",                                    
#                     "emea_vdma_material_handling","emea_vdma_oil_hydraulic")]

df <- danfoss
colSums(is.na(df))

df <- df[,colSums(is.na(df))==0]

sample_train <- df %>% filter(year < 2022)
sample_test <- df %>% filter(year >= 2022)

ts_train_uni <- ts(sample_train$target_variable , start = c(2008,3) , frequency = 12)

arima_model <- auto.arima(ts_train_uni , seasonal.test = "seas")
arima_model
arima_pred = forecast(arima_model , h = 5)
arima_pred <- as.data.frame(arima_pred$mean)


plot(forecast(arima_model , h=6)) #arima plot

df_cols <- colnames(sample_train)
df_cols[-c(1,3)]

sample_test

pred_data <- sample_test %>%add_column(arima_pred = arima_pred$x)

pred_data <- pred_data %>%add_column(arima_date = as.Date(paste(pred_data$year,pred_data$month,"01", sep="/"), format = "%Y/%m/%d"))
as.Date(paste(pred_data$year,pred_data$month,"01", sep="/"), format = "%Y/%m/%d")

pred_data %>% gather(key = "predictions" , value = "value" , c(target_variable,arima_pred))%>% 
  ggplot(aes(x = arima_date ,y =  value , colour = predictions)) + geom_line() + scale_x_date(date_breaks = "1 month")

RMSE(pred_data$arima_pred, pred_data$target_variable)

ts_final_uni <- ts(df$target_variable , start = c(2008,3) , frequency = 12)

arima_model_final <- auto.arima(ts_final_uni , seasonal.test = "seas"   )
arima_pred_final = forecast(arima_model_final , h = 6)
arima_pred_final <- as.data.frame(arima_pred_final$mean)

arima_model_final

coeftest(arima_model_final)

plot(forecast(arima_model_final , h=7)) #arima plot
print(arima_pred_final)



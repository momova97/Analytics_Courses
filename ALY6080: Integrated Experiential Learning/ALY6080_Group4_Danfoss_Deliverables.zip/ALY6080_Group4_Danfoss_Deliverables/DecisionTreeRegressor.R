#install packages
install.packages("plyr")
install.packages("readr")
install.packages("caret")
install.packages("ggplot2")
install.packages("repr")
install.packages("janitor")
install.packages("ISLR")
install.packages("dplyr")
install.packages("tidyrplyr")
install.packages("tidyverse")
install.packages("caTools")
install.packages("corrplot")
install.packages("glmnet")
install.packages("Metrics")
install.packages("rsample")
install.packages("rpart")
install.packages("rpart.plot")
install.packages("ipred")

#load libraries
library(dplyr)
library(tidyverse)
library(plyr)
library(readr)
library(dplyr)
library(caret)
library(ggplot2)
library(repr)
library(janitor)
library(caTools)
library(corrplot)
library(glmnet)
library(Metrics)
library(rsample)     # data splitting 
library(rpart)       # performing regression trees
library(rpart.plot)  # plotting regression trees
library(ipred)       # bagging
library(gbm)


danfoss <- read.csv("Danfoss_FinalData.csv")
danfoss <- as.data.frame(read.csv("Danfoss_FinalData.csv",header = TRUE))
summary(danfoss)
glimpse(danfoss)
# Removing the missing value rows and columns
danfoss <- danfoss[-c(172, 173), ]
names(danfoss) <- make_clean_names(names(danfoss))

# #df <- danfoss[ , c("target_variable","emea_business_confidence_indicator_bci","emea_cli_normalized",
#                    "emea_consumer_confidence_indicator_cci","emea_crude_oil_prices",
#                    "emea_gdp_normalized","emea_germany_ifo_business_climate","emea_ifo_business_expectations","emea_ifo_business_situation",                                   
#                    "emea_pmi","emea_production_in_total_manufacturing_index","emea_production_of_total_construction_index","emea_production_of_total_industry_index",
#                    "emea_vdma_agriculture","emea_vdma_construction","emea_vdma_machine_building",                                    
#                    "emea_vdma_material_handling","emea_vdma_oil_hydraulic")]

df <- danfoss

df <- df[,colSums(is.na(df))==0]

df["year"] <- (df["year"]-2008)

corrplot(cor(df), method = 'number', number.cex = .6,tl.cex=0.7)

#creating training and testing datasets
# Splitting data in train and test data
#df[is.na(df)] <- 0
#Split data into train and test sets
set.seed(3456)
trainIndex <- sample(x = nrow(df), size = nrow(df)* 0.7)
trainIndex
train <- df[ trainIndex,]
test <- df[-trainIndex,]


#Converting train data into matrix
train_x <- model.matrix(target_variable ~., train)[,-1]
test_x <- model.matrix(target_variable ~., test)[,-1]

train_y <- train$target_variable
test_y <- test$target_variable

m1 <- rpart(
  formula = target_variable ~ .,
  data    = train,
  method  = "anova"
)

m2 <- rpart(
  formula = target_variable ~ .,
  data    = train,
  method  = "anova", 
  control = list(cp = 0, xval = 15)
)

plotcp(m2)
abline(v = 9, lty = "dashed")


m3 <- rpart(
  formula = target_variable ~ .,
  data    = train,
  method  = "anova", 
  control = list(minsplit = 10, maxdepth = 12, xval = 10)
)

m3$cptable


hyper_grid <- expand.grid(
  minsplit = seq(1, 20, 1),
  maxdepth = seq(1, 30, 1)
)

head(hyper_grid)


models <- list()

for (i in 1:nrow(hyper_grid)) {
  
  # get minsplit, maxdepth values at row i
  minsplit <- hyper_grid$minsplit[i]
  maxdepth <- hyper_grid$maxdepth[i]
  
  # train a model and store in the list
  models[[i]] <- rpart(
    formula = target_variable ~ .,
    data    = train,
    method  = "anova",
    control = list(minsplit = minsplit, maxdepth = maxdepth)
  )
}


# function to get optimal cp
get_cp <- function(x) {
  min    <- which.min(x$cptable[, "xerror"])
  cp <- x$cptable[min, "CP"] 
}

# function to get minimum error
get_min_error <- function(x) {
  min    <- which.min(x$cptable[, "xerror"])
  xerror <- x$cptable[min, "xerror"] 
}

hyper_grid %>%
  mutate(
    cp    = purrr::map_dbl(models, get_cp),
    error = purrr::map_dbl(models, get_min_error)
  ) %>%
  arrange(error) %>%
  top_n(-5, wt = error)


optimal_tree <- rpart(
  formula = target_variable ~ .,
  data    = train,
  method  = "anova",
  control = list(minsplit = 4, maxdepth = 12, cp = 0.01)
)

pred <- predict(optimal_tree, newdata = test)
RMSE(pred = pred, obs = test$target_variable)




# assess 10-50 bagged trees
ntree <- 100:150

# create empty vector to store OOB RMSE values
rmse <- vector(mode = "numeric", length = length(ntree))

for (i in seq_along(ntree)) {
  # reproducibility
  #set.seed(123)
  
  # perform bagged model
  model <- bagging(
    formula = target_variable ~ .,
    data    = train,
    coob    = TRUE,
    nbagg   = ntree[i]
  )
  # get OOB error
  rmse[i] <- model$err
}

plot(ntree, rmse, type = 'l', lwd = 2)
abline(v = 25, col = "red", lty = "dashed")




# Specify 10-fold cross validation
ctrl <- trainControl(method = "cv",  number = 10) 

# CV bagged model
bagged_cv <- train(
  target_variable ~ .,
  data = train,
  method = "treebag",
  trControl = ctrl,
  importance = TRUE
)

# assess results
bagged_cv

plot(varImp(bagged_cv), 20) 

pred <- predict(bagged_cv, test)
RMSE(pred, test$target_variable)




tc = trainControl(method = "cv", number=10)
model = train(target_variable ~., data=train, method="gbm", trControl=tc)

pred_y = predict(model, test)
print(model)
RMSE(test$target_variable, pred_y)

x_ax = 1:length(pred_y)
plot(x_ax, test$target_variable, col="blue", pch=20, cex=.9)
lines(x_ax, pred_y, col="red", pch=20, cex=.9)
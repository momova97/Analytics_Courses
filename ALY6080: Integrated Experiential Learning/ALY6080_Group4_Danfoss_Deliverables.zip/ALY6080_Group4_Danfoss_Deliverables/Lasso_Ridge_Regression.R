#install packages
install.packages("plyr")
install.packages("readr")
install.packages("caret")
install.packages("ggplot2")
install.packages("repr")
install.packages("janitor")
install.packages("ISLR")
install.packages("dplyr")
install.packages("tidyrplyr")
install.packages("tidyverse")
install.packages("caTools")
install.packages("corrplot")
install.packages("glmnet")
install.packages("Metrics")

#load libraries
library(dplyr)
library(tidyverse)
library(plyr)
library(readr)
library(dplyr)
library(caret)
library(ggplot2)
library(repr)
library(janitor)
library(caTools)
library(corrplot)
library(glmnet)
library(Metrics)


danfoss <- read.csv("Danfoss_FinalData.csv")
danfoss <- as.data.frame(read.csv("Danfoss_FinalData.csv",header = TRUE))
summary(danfoss)
glimpse(danfoss)
# Removing the missing value rows and columns
danfoss <- danfoss[-c(172, 173), ]
names(danfoss) <- make_clean_names(names(danfoss))

# #df <- danfoss[ , c("target_variable","emea_business_confidence_indicator_bci","emea_cli_normalized",
#                     "emea_consumer_confidence_indicator_cci","emea_crude_oil_prices",
#                     "emea_gdp_normalized","emea_germany_ifo_business_climate","emea_ifo_business_expectations","emea_ifo_business_situation",                                   
#                     "emea_pmi","emea_production_in_total_manufacturing_index","emea_production_of_total_construction_index","emea_production_of_total_industry_index",
#                     "emea_vdma_agriculture","emea_vdma_construction","emea_vdma_machine_building",                                    
#                     "emea_vdma_material_handling","emea_vdma_oil_hydraulic")]

df <- danfoss
colSums(is.na(df))

# df$emea_employment_rate[is.na(df$emea_employment_rate)]<- mean(df$emea_employment_rate, na.rm = TRUE)
# 
# df$emea_production_of_total_manufactured_intermediate_goods_index[is.na(df$emea_production_of_total_manufactured_intermediate_goods_index)]<- mean(df$emea_production_of_total_manufactured_intermediate_goods_index, na.rm = TRUE)
# 
# df$emea_production_of_total_manufactured_investment_goods_index[is.na(df$emea_production_of_total_manufactured_investment_goods_index)]<- mean(df$emea_production_of_total_manufactured_investment_goods_index, na.rm = TRUE)
# 
# df$emea_residential_property_sales_of_newly_built_dwelings[is.na(df$emea_residential_property_sales_of_newly_built_dwelings)]<- mean(df$emea_residential_property_sales_of_newly_built_dwelings, na.rm = TRUE)

df <- df[,colSums(is.na(df))==0]

df["year"] <- (df["year"]-2008)

corrplot(cor(df), method = 'number', number.cex = .6,tl.cex=0.7)

#creating training and testing datasets
# Splitting data in train and test data
df[is.na(df)] <- 0
#Split data into train and test sets
set.seed(3456)
trainIndex <- sample(x = nrow(df), size = nrow(df)* 0.7)
trainIndex
train <- df[ trainIndex,]
test <- df[-trainIndex,]

#Converting train data into matrix
train_x <- model.matrix(target_variable ~., train)[,-1]
test_x <- model.matrix(target_variable ~., test)[,-1]

train_y <- train$target_variable
test_y <- test$target_variable


lr = lm(target_variable ~ ., data = train)
summary(lr)

#Step 1 - create the evaluation metrics function

eval_metrics = function(model, df, predictions, target){
  resids = df[,target] - predictions
  resids2 = resids**2
  N = length(predictions)
  r2 = as.character(round(summary(model)$r.squared, 2))
  adj_r2 = as.character(round(summary(model)$adj.r.squared, 2))
  print(adj_r2) #Adjusted R-squared
  print(as.character(round(sqrt(sum(resids2)/N), 2))) #RMSE
}

# Step 2 - predicting and evaluating the model on train data
predictions = predict(lr, newdata = train)
eval_metrics(lr, train, predictions, target = 'target_variable')

# Step 3 - predicting and evaluating the model on test data
predictions = predict(lr, newdata = test)
eval_metrics(lr, test, predictions, target = 'target_variable')

#Ridge Regression

lambdas <- 10^seq(2, -3, by = -.1)
ridge_reg = glmnet(train_x, train_y, nlambda = 10, alpha = 0, family = 'gaussian', lambda = lambdas)

summary(ridge_reg)

#Find optimal lambda value using cross validation
cv_ridge <- cv.glmnet(train_x, train_y, alpha = 0, lambda = lambdas, nfolds = 10)
cv_ridge

#find optimal lambda value that minimizes test MSE 
log(cv_ridge$lambda.min)

#find the lambda 1se
log(cv_ridge$lambda.1se)

optimal_lambda <- cv_ridge$lambda.min
optimal_lambda

plot(cv_ridge)

# Compute R^2 from true and predicted values
eval_results <- function(true, predicted, df) {
  SSE <- sum((predicted - true)^2)
  SST <- sum((true - mean(true))^2)
  R_square <- 1 - SSE / SST
  RMSE = sqrt(SSE/nrow(df))
  
  
  # Model performance metrics
  data.frame(
    RMSE = RMSE,
    Rsquare = R_square
  )
  
}

# Prediction and evaluation on train data
predictions_train <- predict(ridge_reg, s = optimal_lambda, newx = train_x)
eval_results(train_y, predictions_train, train_x)

# Prediction and evaluation on test data
predictions_test <- predict(ridge_reg, s = optimal_lambda, newx = test_x)
eval_results(test_y, predictions_test, test_x)


#lasso Regression
lambdas <- 10^seq(2, -10, by = -.1)

set.seed(3456)
cv.lasso <- cv.glmnet(train_x, train_y, alpha = 1, nfolds = 10)
cv.lasso
plot(cv.lasso)

# Setting alpha = 1 implements lasso regression
lasso_reg <- cv.glmnet(train_x, train_y, alpha = 1, lambda = lambdas, standardize = TRUE, nfolds = 10)

# Best 
lambda_best <- lasso_reg$lambda.min 
lambda_best

lasso_model <- glmnet(train_x, train_y, alpha = 1, lambda = lambda_best, standardize = TRUE)
lasso_model

#find optimal lambda value that minimizes test MSE 
#log(lasso_reg$lambda.min)
log(cv.lasso$lambda.min)

#find the lambda 1se
#log(lasso_reg$lambda.1se)
log(cv.lasso$lambda.1se)

plot(lasso_reg)


predictions_train <- predict(lasso_model, s = lambda_best, newx = train_x)
eval_results(train_y, predictions_train, train_x)

predictions_test <- predict(lasso_model, s = lambda_best, newx = test_x)
eval_results(test_y, predictions_test, test_x)

install.packages("ISLR")
install.packages("dplyr")
install.packages("tidyrplyr")
install.packages("tidyverse")
install.packages("ggplot2")
install.packages("corrplot")
library(dplyr)
library(tidyrplyr)
library(tidyverse)
library(ggplot2)
library(corrplot)


danfoss <- read.csv("Danfoss_FinalData (1).csv")
summary(danfoss)

hist(danfoss$TARGET.VARIABLE)

str(danfoss)
sapply(danfoss, function(x)sum(is.na(x)))
corrplot(danfoss, method = 'number')
danfoss1 <- danfoss[ , c('TARGET.VARIABLE', 'EMEA..VDMA.Agriculture','EMEA..VDMA.Construction','EMEA..VDMA.Machine.Building')]
corrplot(danfoss1, method = 'number')

boxplot(danfoss1)
#cleaning names so they are easier to use
library(janitor)
danfoss<-danfoss %>% clean_names()
colnames(danfoss)
# creating randomforset model for predicting target varible
str(danfoss)
# Loading package
library(caTools)
library(randomForest)
#creating training and testing datasets
# Splitting data in train and test data
danfoss[is.na(danfoss)] <- 0
set.seed(100)
split <- sample.split(danfoss, SplitRatio = 0.7)
split

train <- subset(danfoss, split == "TRUE")
test <- subset(danfoss, split == "FALSE")
# Fitting Random Forest to the train dataset

#tuning the model
a=c()
i=5
set.seed(100)
for (i in 3:23) {
  model3 <- randomForest(target_variable ~ ., data = train, ntree = 200, mtry = i, importance = TRUE)
  predValid <- predict(model3, newdata = test[-3])
  a[i-2] = mean(abs(predValid - test$target_variable))
}
plot(3:23,a)
a
#best models so far
set.seed(100)  # Setting seed
classifier_RF = randomForest(x = train[-3],
                             ntree = 200, mtry = 21,
                             y = train$target_variable,)
classifier_RF

# Predicting the Test set results
yhat=predict(classifier_RF,newdata=test[-3])
plot(x = yhat,y = test$target_variable)
abline(0,1)
mean((yhat-test$target_variable)^2)
varImpPlot(classifier_RF)

#plotting sample tree
install.packages(part)
library('party')
set.seed(100)
y <- cforest(target_variable ~ ., data = train, controls=cforest_unbiased(mtry = 21, ntree = 200))
er <-proximity(y, newdata = test)
print(er)
#getting a tree out of Randomforest
get_cTree <- function(cf, k=1) {
  dt <- cf@data@get("input")
  tr <- party:::prettytree(cf@ensemble[[k]], names(dt))
  tr_updated <- update_tree(tr, dt)
  new("BinaryTree", tree=tr_updated, data=cf@data, responses=cf@responses, 
      cond_distr_response=cf@cond_distr_response, predict_response=cf@predict_response)
}

update_tree <- function(x, dt) {
  x <- update_weights(x, dt)
  if(!x$terminal) {
    x$left <- update_tree(x$left, dt)
    x$right <- update_tree(x$right, dt)   
  } 
  x
}

update_weights <- function(x, dt) {
  splt <- x$psplit
  spltClass <- attr(splt,"class")
  spltVarName <- splt$variableName
  spltVar <- dt[,spltVarName]
  spltVarLev <- levels(spltVar)
  if (!is.null(spltClass)) {
    if (spltClass=="nominalSplit") {
      attr(x$psplit$splitpoint,"levels") <- spltVarLev   
      filt <- spltVar %in% spltVarLev[as.logical(x$psplit$splitpoint)] 
    } else {
      filt <- (spltVar <= splt$splitpoint)
    }
    x$left$weights <- as.numeric(filt)
    x$right$weights <- as.numeric(!filt)
  }
  x
}

plot(get_cTree(y, 1))

